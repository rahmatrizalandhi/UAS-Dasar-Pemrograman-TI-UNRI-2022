import React from "react";

const EditableRow = ({
  editFormData,
  handleEditFormChange,
  handleCancelClick,
}) => {
  return (
    <tr>
      <td>
        <input
          type="text"
          required="required"
          placeholder="Ketik nama"
          name="Nama"
          value={editFormData.nama}
          onChange={handleEditFormChange}
          ></input>
      </td>
      <td>
        <input
          type="text"
          required="required"
          placeholder="Ketik Tanggal Lahir"
          name="Tanggal Lahir"
          value={editFormData.tanggallahir}
          onChange={handleEditFormChange}
        ></input>
      </td>
      <td>
        <input
          type="text"
          required="required"
          placeholder="Ketik alamat"
          name="Alamat"
          value={editFormData.alamat}
          onChange={handleEditFormChange}
        ></input>
      </td>
      <td>
        <input
          type="text"
          required="required"
          placeholder="Ketik No. Handphone"
          name="No. Handphone"
          value={editFormData.noHandphone}
          onChange={handleEditFormChange}
        ></input>
      </td>
      <td>
        <button type="submit">Save</button>
        <button type="button" onClick={handleCancelClick}>
          Cancel
        </button>
      </td>
    </tr>
  );
};

export default EditableRow;

